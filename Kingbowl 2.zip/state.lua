state = {
  game = nil,
  gui = nil
}

return state
