player = {
  direction = 0
  isMoving = false
}

return player
